//
//  RecipeCollectionViewCell.swift
//  Flavorful
//
//  Created by Slarve N. on 3/26/21.
//

import UIKit

class RecipeCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet var recipeImageView: UIImageView!
    @IBOutlet var recipeNameLabel: UILabel!
    
}
