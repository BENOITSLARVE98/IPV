//
//  FavoriteCollectionViewCell.swift
//  Flavorful
//
//  Created by Slarve N. on 4/3/21.
//

import UIKit

class FavoriteCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var recipeImageView: UIImageView!
    @IBOutlet var recipeNameLabel: UILabel!
    
}
